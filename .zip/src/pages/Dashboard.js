import React, { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

const Dashboard = () => {
  const { user, logout } = useContext(AuthContext);

  return (
    <div>
      <h1>Welcome to Dashboard</h1>

      <p>You are logged in successfully.</p>

      <p>
        <strong>Authentication Token:</strong>
      </p>

      <textarea
        value={user?.token || ""}
        readOnly
        rows="5"
        cols="80"
      />

      <br />

      <button onClick={logout}>
        Logout
      </button>
    </div>
  );
};

export default Dashboard;