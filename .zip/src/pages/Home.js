import React from "react";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div>
      <h1>Welcome to MessMate</h1>

      <p>Find and manage your mess listings.</p>

      <Link to="/login">
        <button>Login</button>
      </Link>

      <Link to="/dashboard">
        <button>Dashboard</button>
      </Link>
    </div>
  );
};

export default Home;